use Training_19Sep19_Pune



Create PROCEDURE [bhargav].[InsertEmployee]

@EmpID int,

@EmpName varchar(50),

@Gender char(10),

@Location varchar(50),

@ContactNo varchar(10),

@BloodGroup varchar(10),

@Coverage int

AS

BEGIN

 insert into [bhargav].[EmpMarathon] values(@EmpID,@EmpName,@Gender,@Location,@ContactNo,@BloodGroup,@Coverage)

END



GO