use Training_19Sep19_Pune
go

create schema [bhargav]

CREATE TABLE [bhargav].[EmpMarathon](

 EmpID int  NOT NULL,

 EmpName varchar(50) NOT NULL,

 Location varchar(50) NOT NULL,

 ContactNo varchar(10) NOT NULL,

 Coverage varchar(4) NOT NULL,

 Gender varchar(10) NOT NULL,

 BloodGroup varchar(10) NOT NULL
 )

PRIMARY KEY CLUSTERED

(

 EmpID ASC

)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

) ON [PRIMARY]



GO



SET ANSI_PADDING OFF

GO


