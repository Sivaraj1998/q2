﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarathonDAL;
using MarathonEntity;
using MarathonException;

namespace MarathonBAL
{
    public class BAL
    {

        DAL marathonDAL = new DAL();

        public bool IsValid(Marathon marathon)
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;
            if (marathon.EmpID.ToString().Length !=6)
            {
                sb.Append("EmpID must be 6 Digit Value" + Environment.NewLine);
                isValid = false;
            }
            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }
            return isValid;
        }

        public bool AddBAL(Marathon marathon)
        {
            bool no = false;
            try
            {
                if (IsValid(marathon))
                    no = marathonDAL.AddMarathonDAL(marathon);
            }
            catch (Marathon_Exceptions)
            {
                throw;
            }
            return no;
        }
    }
}
