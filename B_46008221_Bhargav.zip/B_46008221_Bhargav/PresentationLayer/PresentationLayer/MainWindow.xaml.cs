﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MarathonBAL;
using MarathonEntity;
using MarathonException;

namespace PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        BAL marBL = new BAL();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Marathon marathon = new Marathon();
                if (txtEmpId.Text == string.Empty ||
                    txtEmpName.Text == string.Empty ||
                    cbGender.Text == string.Empty ||
                    cbLocation.Text == string.Empty ||
                    txtContactNo.Text == string.Empty ||
                    cbBloodGroup.Text == string.Empty ||
                    cbCoverage.Text == string.Empty)
                {
                    MessageBox.Show("Please Enter All Fields");
                }

                else
                {
                    marathon.EmpID = Convert.ToInt32(txtEmpId.Text);
                    marathon.Gender = ((ComboBoxItem)cbGender.SelectedItem).Content.ToString();
                    marathon.EmpName = txtEmpName.Text;
                    marathon.Location = ((ComboBoxItem)cbLocation.SelectedItem).Content.ToString();
                    marathon.ContactNo = txtContactNo.Text;
                    marathon.BloodGroup = ((ComboBoxItem)cbBloodGroup.SelectedItem).Content.ToString();
                    marathon.Coverage = ((ComboBoxItem)cbCoverage.SelectedItem).Content.ToString();
                }
            }
            catch (Marathon_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
        txtEmpId.Clear();
        cbGender.SelectedIndex = -1;
        txtEmpName.Clear();
        cbLocation.SelectedIndex = -1;
        txtContactNo.Clear();
        cbBloodGroup.SelectedIndex = -1;
        cbCoverage.SelectedIndex = -1;
    }

    }
}
