﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarathonEntity;
using MarathonException;
using System.Configuration;
using System.Data;

namespace MarathonDAL
{
    public class DAL
    {
        public bool AddMarathonDAL(Marathon objMarathon)
        {
            bool MarathonAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["MarathonRunner"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[bhargav].[InsertEmployee]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_EmpID = new SqlParameter("@EmpID", objMarathon.EmpID);
                SqlParameter objSqlParam_EmpName = new SqlParameter("@EmpName", objMarathon.EmpName);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender ", objMarathon.Gender);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location ", objMarathon.Location);
                SqlParameter objSqlParam_ContactNo = new SqlParameter("@ ContactNo ", objMarathon.ContactNo);
                SqlParameter objSqlParam_BloodGroup = new SqlParameter("@BloodGroup", objMarathon.BloodGroup);
                SqlParameter objSqlParam_Coverage = new SqlParameter("@Coverage", objMarathon.Coverage);
                //
                objCom.Parameters.Add(objSqlParam_EmpID);
                objCom.Parameters.Add(objSqlParam_EmpName);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_ContactNo);
                objCom.Parameters.Add(objSqlParam_BloodGroup);
                objCom.Parameters.Add(objSqlParam_Coverage);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                MarathonAdded = true;
            }
            catch (Marathon_Exceptions ex)
            {
                throw ex;
            }
            finally
            {
                objCon.Close();
            }
            return MarathonAdded;
        }

    }
}
