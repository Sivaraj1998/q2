﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarathonEntity
{
    public class Marathon
    {
        public int EmpID { get; set; }

        public string EmpName { get; set; }

        public string Gender { get; set; }

        public string Location { get; set; }

        public string ContactNo { get; set; }

        public string BloodGroup { get; set; }

        public string Coverage { get; set; }

    }
}
