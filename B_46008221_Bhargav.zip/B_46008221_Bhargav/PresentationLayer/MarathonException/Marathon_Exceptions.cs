﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarathonException
{
  
        public class Marathon_Exceptions : Exception
        {
            public Marathon_Exceptions() : base()
            {

            }

            public Marathon_Exceptions(string message) : base(message)
            {

            }

            public Marathon_Exceptions(string message, Exception innerException) : base(message, innerException)
            {

            }
        }
    }

